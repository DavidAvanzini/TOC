import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Diagram, Milestone, Activity, Selection } from '../types';

const STATION_RADIUS = 18;
const GRID_SIZE = 40;

interface Props {
  diagram: Diagram;
  computedActivities: Activity[];
  selection: Selection;
  onSelectMilestone: (id: string) => void;
  onSelectActivity: (id: string) => void;
  onMoveMilestone: (id: string, x: number, y: number) => void;
  onAddMilestone: (x: number, y: number) => void;
  tool: 'select' | 'add-milestone' | 'add-activity';
  onConnectMilestones: (fromId: string, toId: string) => void;
  showCritical: boolean;
}

function snapToGrid(v: number) {
  return Math.round(v / GRID_SIZE) * GRID_SIZE;
}

export function DiagramCanvas({
  diagram,
  computedActivities,
  selection,
  onSelectMilestone,
  onSelectActivity,
  onMoveMilestone,
  onAddMilestone,
  tool,
  onConnectMilestones,
  showCritical,
}: Props) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [dragging, setDragging] = useState<{ id: string; ox: number; oy: number } | null>(null);
  const [connecting, setConnecting] = useState<{ fromId: string; mx: number; my: number } | null>(null);
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, w: 1400, h: 700 });
  const [panning, setPanning] = useState<{ startX: number; startY: number; vbx: number; vby: number } | null>(null);

  const toSVG = useCallback((clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const rect = svg.getBoundingClientRect();
    const scaleX = viewBox.w / rect.width;
    const scaleY = viewBox.h / rect.height;
    return {
      x: (clientX - rect.left) * scaleX + viewBox.x,
      y: (clientY - rect.top) * scaleY + viewBox.y,
    };
  }, [viewBox]);

  const getPath = (id: string) => diagram.paths.find(p => p.id === id);
  const getMilestone = (id: string) => diagram.milestones.find(m => m.id === id);

  const handleSvgMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    if (e.target === svgRef.current || (e.target as Element).classList.contains('grid-bg')) {
      if (tool === 'add-milestone') {
        const pos = toSVG(e.clientX, e.clientY);
        onAddMilestone(snapToGrid(pos.x), snapToGrid(pos.y));
        return;
      }
      if (tool === 'select') {
        setPanning({ startX: e.clientX, startY: e.clientY, vbx: viewBox.x, vby: viewBox.y });
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (dragging) {
      const pos = toSVG(e.clientX, e.clientY);
      onMoveMilestone(dragging.id, snapToGrid(pos.x - dragging.ox), snapToGrid(pos.y - dragging.oy));
    }
    if (connecting) {
      const pos = toSVG(e.clientX, e.clientY);
      setConnecting(c => c ? { ...c, mx: pos.x, my: pos.y } : null);
    }
    if (panning) {
      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      const dx = (e.clientX - panning.startX) * (viewBox.w / rect.width);
      const dy = (e.clientY - panning.startY) * (viewBox.h / rect.height);
      setViewBox(v => ({ ...v, x: panning.vbx - dx, y: panning.vby - dy }));
    }
  };

  const handleMouseUp = () => {
    setDragging(null);
    setPanning(null);
    if (connecting) setConnecting(null);
  };

  const handleMilestoneMouseDown = (e: React.MouseEvent, m: Milestone) => {
    e.stopPropagation();
    if (tool === 'select') {
      onSelectMilestone(m.id);
      const pos = toSVG(e.clientX, e.clientY);
      setDragging({ id: m.id, ox: pos.x - m.x, oy: pos.y - m.y });
    } else if (tool === 'add-activity') {
      const pos = toSVG(e.clientX, e.clientY);
      setConnecting({ fromId: m.id, mx: pos.x, my: pos.y });
    }
  };

  const handleMilestoneMouseUp = (e: React.MouseEvent, m: Milestone) => {
    e.stopPropagation();
    if (connecting && connecting.fromId !== m.id) {
      onConnectMilestones(connecting.fromId, m.id);
      setConnecting(null);
    }
  };

  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      const factor = e.deltaY > 0 ? 1.1 : 0.9;
      const mx = (e.clientX - rect.left) / rect.width;
      const my = (e.clientY - rect.top) / rect.height;
      setViewBox(v => {
        const nw = Math.min(3000, Math.max(400, v.w * factor));
        const nh = Math.min(2000, Math.max(300, v.h * factor));
        const nx = v.x + mx * (v.w - nw);
        const ny = v.y + my * (v.h - nh);
        return { x: nx, y: ny, w: nw, h: nh };
      });
    };
    const el = svgRef.current;
    el?.addEventListener('wheel', handleWheel, { passive: false });
    return () => el?.removeEventListener('wheel', handleWheel);
  }, []);

  // Build activity route: straight lines with metro-style bends
  const buildPath = (act: Activity): string => {
    const from = getMilestone(act.fromMilestoneId);
    const to = getMilestone(act.toMilestoneId);
    if (!from || !to) return '';
    const x1 = from.x, y1 = from.y, x2 = to.x, y2 = to.y;
    if (y1 === y2) return `M ${x1} ${y1} L ${x2} ${y2}`;
    const midX = (x1 + x2) / 2;
    const r = 24;
    if (x2 > x1) {
      return `M ${x1} ${y1} L ${midX - r} ${y1} Q ${midX} ${y1} ${midX} ${y1 + (y2 > y1 ? r : -r)} L ${midX} ${y2 - (y2 > y1 ? r : -r)} Q ${midX} ${y2} ${midX + r} ${y2} L ${x2} ${y2}`;
    }
    return `M ${x1} ${y1} L ${midX + r} ${y1} Q ${midX} ${y1} ${midX} ${y1 + (y2 > y1 ? r : -r)} L ${midX} ${y2 - (y2 > y1 ? r : -r)} Q ${midX} ${y2} ${midX - r} ${y2} L ${x2} ${y2}`;
  };

  const actMidpoint = (act: Activity) => {
    const from = getMilestone(act.fromMilestoneId);
    const to = getMilestone(act.toMilestoneId);
    if (!from || !to) return null;
    return { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 };
  };

  return (
    <svg
      ref={svgRef}
      className="w-full h-full"
      viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
      onMouseDown={handleSvgMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: tool === 'add-milestone' ? 'crosshair' : tool === 'add-activity' ? 'cell' : 'default', background: '#0f1117' }}
    >
      <defs>
        <pattern id="grid" width={GRID_SIZE} height={GRID_SIZE} patternUnits="userSpaceOnUse">
          <path d={`M ${GRID_SIZE} 0 L 0 0 0 ${GRID_SIZE}`} fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
        </pattern>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge><feMergeNode in="coloredBlur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <filter id="glow-strong">
          <feGaussianBlur stdDeviation="5" result="coloredBlur" />
          <feMerge><feMergeNode in="coloredBlur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        {diagram.paths.map(p => (
          <marker key={p.id} id={`arrow-${p.id}`} markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
            <path d="M 0 0 L 6 3 L 0 6 z" fill={p.color} />
          </marker>
        ))}
        <marker id="arrow-connecting" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
          <path d="M 0 0 L 6 3 L 0 6 z" fill="rgba(255,255,255,0.5)" />
        </marker>
      </defs>

      {/* Grid */}
      <rect className="grid-bg" x={viewBox.x - 1000} y={viewBox.y - 1000} width={viewBox.w + 2000} height={viewBox.h + 2000} fill="url(#grid)" />

      {/* Connecting preview */}
      {connecting && (() => {
        const from = getMilestone(connecting.fromId);
        if (!from) return null;
        return (
          <line
            x1={from.x} y1={from.y}
            x2={connecting.mx} y2={connecting.my}
            stroke="rgba(255,255,255,0.4)" strokeWidth="2" strokeDasharray="6 4"
            markerEnd="url(#arrow-connecting)"
          />
        );
      })()}

      {/* Activities */}
      {computedActivities.map(act => {
        const path = getPath(act.pathId);
        if (!path) return null;
        const d = buildPath(act);
        if (!d) return null;
        const isSelected = selection.type === 'activity' && selection.id === act.id;
        const isCritical = showCritical && act.isCritical;
        const mid = actMidpoint(act);
        return (
          <g key={act.id}>
            {/* Hit area */}
            <path
              d={d} fill="none" stroke="transparent" strokeWidth="16"
              style={{ cursor: 'pointer' }}
              onClick={(e) => { e.stopPropagation(); onSelectActivity(act.id); }}
            />
            {/* Shadow for critical */}
            {isCritical && (
              <path d={d} fill="none" stroke="#ffcc00" strokeWidth="6" opacity="0.3" filter="url(#glow-strong)" />
            )}
            {/* Main line */}
            <path
              d={d} fill="none"
              stroke={path.color}
              strokeWidth={isSelected ? 5 : 3}
              strokeDasharray={isCritical ? undefined : undefined}
              markerEnd={`url(#arrow-${path.id})`}
              filter={isSelected ? 'url(#glow)' : undefined}
              opacity={isSelected ? 1 : 0.85}
            />
            {/* Critical overlay */}
            {isCritical && (
              <path d={d} fill="none" stroke="#ffcc00" strokeWidth="1.5" strokeDasharray="8 6" opacity="0.9" />
            )}
            {/* Activity label */}
            {mid && (
              <g>
                <rect
                  x={mid.x - act.name.length * 3.5 - 4} y={mid.y - 11}
                  width={act.name.length * 7 + 8} height={16}
                  fill="#0f1117" rx="3" opacity="0.85"
                />
                <text
                  x={mid.x} y={mid.y}
                  textAnchor="middle" dominantBaseline="middle"
                  fill={isSelected ? '#fff' : '#c8ccd8'}
                  fontSize="11"
                  style={{ fontFamily: 'Inter, sans-serif', pointerEvents: 'none' }}
                >
                  {act.name}
                </text>
                {act.duration > 0 && (
                  <text
                    x={mid.x} y={mid.y + 13}
                    textAnchor="middle" dominantBaseline="middle"
                    fill={path.color}
                    fontSize="10"
                    style={{ fontFamily: 'JetBrains Mono, monospace', pointerEvents: 'none' }}
                  >
                    {act.duration}d
                  </text>
                )}
              </g>
            )}
          </g>
        );
      })}

      {/* Milestones (stations) */}
      {diagram.milestones.map(m => {
        const isSelected = selection.type === 'milestone' && selection.id === m.id;
        const pathColors = computedActivities
          .filter(a => a.fromMilestoneId === m.id || a.toMilestoneId === m.id)
          .map(a => getPath(a.pathId)?.color)
          .filter(Boolean) as string[];
        const uniqueColors = [...new Set(pathColors)];

        return (
          <g
            key={m.id}
            style={{ cursor: tool === 'select' ? 'grab' : 'crosshair' }}
            onMouseDown={e => handleMilestoneMouseDown(e, m)}
            onMouseUp={e => handleMilestoneMouseUp(e, m)}
            onClick={e => { e.stopPropagation(); if (tool === 'select') onSelectMilestone(m.id); }}
          >
            {/* Outer ring for transfer stations */}
            {uniqueColors.length > 1 && (
              <circle cx={m.x} cy={m.y} r={STATION_RADIUS + 6} fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="2" />
            )}
            {/* Glow when selected */}
            {isSelected && (
              <circle cx={m.x} cy={m.y} r={STATION_RADIUS + 4} fill="none" stroke="#4f9cf9" strokeWidth="2" filter="url(#glow)" opacity="0.7" />
            )}
            {/* Station circle */}
            <circle
              cx={m.x} cy={m.y} r={STATION_RADIUS}
              fill="#0f1117" stroke={isSelected ? '#4f9cf9' : '#e8eaf0'}
              strokeWidth={isSelected ? 3 : 2}
            />
            {/* Color segments for multi-path stations */}
            {uniqueColors.slice(0, 4).map((color, i) => {
              const segAngle = (Math.PI * 2) / uniqueColors.length;
              const startAngle = i * segAngle - Math.PI / 2;
              const endAngle = startAngle + segAngle;
              const r = STATION_RADIUS - 4;
              const x1 = m.x + r * Math.cos(startAngle);
              const y1 = m.y + r * Math.sin(startAngle);
              const x2 = m.x + r * Math.cos(endAngle);
              const y2 = m.y + r * Math.sin(endAngle);
              const largeArc = segAngle > Math.PI ? 1 : 0;
              if (uniqueColors.length === 1) {
                return <circle key={color} cx={m.x} cy={m.y} r={r} fill={color} opacity="0.6" />;
              }
              return (
                <path
                  key={color}
                  d={`M ${m.x} ${m.y} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`}
                  fill={color} opacity="0.6"
                />
              );
            })}
            {/* Station dot */}
            <circle cx={m.x} cy={m.y} r={4} fill={isSelected ? '#4f9cf9' : '#e8eaf0'} />
            {/* Label */}
            <text
              x={m.x} y={m.y + STATION_RADIUS + 14}
              textAnchor="middle"
              fill={isSelected ? '#4f9cf9' : '#e8eaf0'}
              fontSize="12"
              fontWeight={isSelected ? '600' : '500'}
              style={{ fontFamily: 'Inter, sans-serif', pointerEvents: 'none' }}
            >
              {m.name}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
