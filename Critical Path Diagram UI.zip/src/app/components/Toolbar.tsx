import React, { useRef } from 'react';
import { MousePointer2, Circle, GitCommitHorizontal, Save, FolderOpen, Plus, Eye, EyeOff, Download, Upload } from 'lucide-react';
import { Diagram } from '../types';

interface Props {
  tool: 'select' | 'add-milestone' | 'add-activity';
  onToolChange: (t: 'select' | 'add-milestone' | 'add-activity') => void;
  showCritical: boolean;
  onToggleCritical: () => void;
  title: string;
  onTitleChange: (t: string) => void;
  onSave: () => void;
  onLoad: (d: Diagram) => void;
  onNew: () => void;
}

export function Toolbar({ tool, onToolChange, showCritical, onToggleCritical, title, onTitleChange, onSave, onLoad, onNew }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);

  const handleLoad = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const d = JSON.parse(ev.target?.result as string) as Diagram;
        onLoad(d);
      } catch {
        alert('Invalid diagram file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const toolBtn = (active: boolean) =>
    `flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs transition-colors ${active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`;

  const actionBtn = 'flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors';

  return (
    <header className="flex items-center gap-2 px-4 py-2 bg-card border-b border-border shrink-0 z-10">
      {/* Title */}
      <input
        className="bg-transparent border-none outline-none text-foreground placeholder:text-muted-foreground text-base font-semibold min-w-0 flex-1 max-w-xs"
        value={title}
        onChange={e => onTitleChange(e.target.value)}
        placeholder="Untitled Diagram"
      />

      <div className="w-px h-6 bg-border mx-1" />

      {/* Drawing tools */}
      <div className="flex items-center gap-1">
        <button className={toolBtn(tool === 'select')} onClick={() => onToolChange('select')} title="Select / Pan">
          <MousePointer2 size={14} /> Select
        </button>
        <button className={toolBtn(tool === 'add-milestone')} onClick={() => onToolChange('add-milestone')} title="Add Milestone (click canvas)">
          <Circle size={14} /> Station
        </button>
        <button className={toolBtn(tool === 'add-activity')} onClick={() => onToolChange('add-activity')} title="Add Activity (drag between stations)">
          <GitCommitHorizontal size={14} /> Activity
        </button>
      </div>

      <div className="w-px h-6 bg-border mx-1" />

      {/* CPM view */}
      <button className={toolBtn(showCritical)} onClick={onToggleCritical} title="Highlight critical path">
        {showCritical ? <Eye size={14} /> : <EyeOff size={14} />}
        Critical
      </button>

      <div className="w-px h-6 bg-border mx-1" />

      {/* File actions */}
      <button className={actionBtn} onClick={onNew} title="New diagram">
        <Plus size={14} /> New
      </button>
      <button className={actionBtn} onClick={onSave} title="Save diagram (JSON)">
        <Save size={14} /> Save
      </button>
      <button className={actionBtn} onClick={() => fileRef.current?.click()} title="Load diagram">
        <FolderOpen size={14} /> Load
      </button>
      <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={handleLoad} />
    </header>
  );
}
