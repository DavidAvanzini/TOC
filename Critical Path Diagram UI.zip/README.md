
  # Critical Path Diagram UI

  This is a code bundle for Critical Path Diagram UI. The original project is available at https://www.figma.com/design/k43JXtAilRPpDd4jMPIaGB/Critical-Path-Diagram-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  